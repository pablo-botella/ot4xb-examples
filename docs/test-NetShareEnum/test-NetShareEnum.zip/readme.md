# test-NetShareEnum
----
Xbase++ version from the C++ example at the bottom of 
[https://docs.microsoft.com/en-us/windows/win32/api/lmshare/nf-lmshare-netshareenum](https://docs.microsoft.com/en-us/windows/win32/api/lmshare/nf-lmshare-netshareenum)
----
usage: test-NetShareEnum.exe %COMPUTERNAME%
----

