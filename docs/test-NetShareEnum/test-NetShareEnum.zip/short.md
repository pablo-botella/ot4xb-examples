Example using `UNICODEDYNSTR` as structure member ,  `gwst:_link_(<pt>,.F.)` and `GwstArrayNext(<st>)' 

