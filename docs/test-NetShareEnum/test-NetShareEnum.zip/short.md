Example using UNICODEDYNSTR as structure memeber ,  gwst:_link_(<pt>,.F.) and GwstArrayNext(<st>)

