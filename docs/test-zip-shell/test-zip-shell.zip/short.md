Using windows shell api to create zip files
 
