#test-get-adapters-info         
  
----  
  
