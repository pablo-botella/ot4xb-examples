#test-stdevp                    
  
----  
  
