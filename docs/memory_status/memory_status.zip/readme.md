#memory_status                  
  
----  
  
