xml-tree-view
  
----  
In this example we are populating an XbpTreeView with the nodes of an xml file and using an html window to display the node properties.
Here we using a bidimensional array to hold all the items, that we using later to populate the tree view control.
  
