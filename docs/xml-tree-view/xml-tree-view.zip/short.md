A simple test using the  xmllite.dll winapi component \( TestXmlLite.prg \)


